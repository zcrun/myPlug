import React from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import { Button } from "antd";
import "./index.less";

export default class CheckButton extends React.Component {
  static defaultProps = {
    options: []
  };

  static propTypes = {
    defaultValue: PropTypes.array,
    value: PropTypes.array,
    options: PropTypes.array.isRequired,
    onChange: PropTypes.func
  };

  constructor(props) {
    super(props);
    this.state = {
      value: props.value || props.defaultValue || []
    };
  }

  // 改变
  onChange = v => {
    const optionIndex = this.state.value.indexOf(v);
    const value = [...this.state.value];
    if (optionIndex === -1) {
      value.push(v);
    } else {
      value.splice(optionIndex, 1);
    }
    this.setState({ value });
    const onChange = this.props.onChange;
    if (onChange) {
      onChange(value);
    }
  };

  render() {
    const { className, options } = this.props;
    const { value } = this.state;

    return (
      <div className={classNames("check-Button", className)}>
        {options.map(item => {
          return (
            <Button
              key={item.value}
              type={value.indexOf(item.value) >= 0 ? "primary" : ""}
              onClick={() => this.onChange(item.value)}
            >
              {item.label}
            </Button>
          );
        })}
      </div>
    );
  }
}
